import React from 'react'
import './ListXs.css';

function ListXs() {
  return (
    <div className='list'>
      <ul className="list-group lst">
          <li className="list-group-item ">Connexion</li>
          <li className="list-group-item">Inscription</li>
     </ul>
    </div>
  )
}
export default ListXs
