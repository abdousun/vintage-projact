import React, { Component } from 'react'
import './Footer.css';

export default class Footer extends Component {
  render() {
    return (
      <div className='footer'>
                <h1 style={{ color: 'white', fontSize: '20px' }}>Copyright © 2024 Vintage Clothes, Inc.</h1>
      </div>
    )
  }
}
